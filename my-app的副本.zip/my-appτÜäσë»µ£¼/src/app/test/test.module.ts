import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HiComponent } from '../hi/hi.component';
import { HelloComponent } from '../hello/hello.component';
import {DemoNgZorroAntdModule} from '../ng-zorro-module';



@NgModule({
  declarations: [HiComponent, HelloComponent],
  imports: [
    CommonModule,
    DemoNgZorroAntdModule
  ],
  exports:[HiComponent,HelloComponent]
})
export class TestModule { }

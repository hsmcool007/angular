import { Component, OnInit } from '@angular/core';
import {HeroService} from '../heroes/hero.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-hi',
  templateUrl: './hi.component.html',
  styleUrls: ['./hi.component.less']
})
export class HiComponent implements OnInit {
  heroes: string;
  constructor(heroService: HeroService) {
    this.heroes = heroService.getHeroes();
  }

  ngOnInit(): void {
  }

}
